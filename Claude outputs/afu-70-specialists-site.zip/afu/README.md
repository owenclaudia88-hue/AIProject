# 70 AI Specialists — landing page + checkout

Standalone site, separate from aifounderuniversity.com.

Flow: index.html (name + email) → checkout.html (pay $1 with Stripe) → success.html

## Go live (about 15 minutes)
1. **Deploy this folder to Vercel** as a NEW project (drag the folder into vercel.com/new or use `vercel` CLI).
   Optionally add a subdomain like go.aifounderuniversity.com under Project → Domains.
2. **Vercel → Project → Settings → Environment Variables**
   - `STRIPE_SECRET_KEY` = your secret key (sk_live_...)
   - `PRICE_CENTS` = 100 (optional, default $1.00)
3. **Edit `config.js`**
   - `stripePublishableKey` = pk_live_...
   - `leadWebhook` = Make / Zapier / Formspree URL (saves every name + email before payment)
   - `metaPixelId` = your pixel ID
   - `accessUrl` = where buyers get the product
4. **Apple Pay**: Stripe Dashboard → Settings → Payment methods → Apple Pay → add your domain.
5. **Deliver access by email**: in Zapier/Make, trigger "Stripe → Payment succeeded" → send the access email
   (the buyer's name and email are on the payment). Stripe also emails a receipt automatically.
6. Test with test keys (pk_test / sk_test, card 4242 4242 4242 4242), then switch to live keys.

## Meta events
PageView (all pages) · Lead (form submitted) · InitiateCheckout (checkout loaded) ·
AddPaymentInfo (pay clicked) · Purchase (success page, once per payment, value $1).
Optimise your campaign for Purchase once you have ~50/week; use Lead or InitiateCheckout before that.
