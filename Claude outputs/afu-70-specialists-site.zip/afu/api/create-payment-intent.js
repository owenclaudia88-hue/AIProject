import Stripe from 'stripe';

/**
 * POST /api/create-payment-intent  { name?, email? }
 * Creates the $1 PaymentIntent the checkout page pays against.
 *
 * The amount comes from the server (PRICE_CENTS), never from the browser,
 * so the price can't be changed by editing the page.
 *
 * Vercel env vars:
 *   STRIPE_SECRET_KEY  sk_live_... (required)
 *   PRICE_CENTS        default 100  ($1.00)
 *   CURRENCY           default usd
 *   PRODUCT_NAME       default "70 AI Specialists for Claude"
 */
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed' });
  }
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) return res.status(500).json({ error: 'Payments are not configured yet.' });

  let body = req.body ?? {};
  if (typeof body === 'string') { try { body = JSON.parse(body || '{}'); } catch { body = {}; } }
  const clean = (v, max) => (typeof v === 'string' ? v.trim().slice(0, max) : '');
  const email = clean(body.email, 320).toLowerCase();
  const name = clean(body.name, 120);
  const validEmail = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);

  const amount = Number.parseInt(process.env.PRICE_CENTS || '100', 10);
  const currency = (process.env.CURRENCY || 'usd').toLowerCase();
  const product = process.env.PRODUCT_NAME || '70 AI Specialists for Claude';

  try {
    const stripe = new Stripe(key);
    const intent = await stripe.paymentIntents.create({
      amount,
      currency,
      description: product,
      automatic_payment_methods: { enabled: true },
      ...(validEmail ? { receipt_email: email } : {}),
      metadata: {
        product,
        name,
        email: validEmail ? email : '',
        source: clean(body.source, 60) || 'lander',
        utm_campaign: clean(body.utm_campaign, 120),
        utm_content: clean(body.utm_content, 120)
      }
    });
    return res.status(200).json({ clientSecret: intent.client_secret, amount, currency });
  } catch (err) {
    console.error('[create-payment-intent]', err.message);
    return res.status(500).json({ error: 'Could not start checkout. Please try again.' });
  }
}
