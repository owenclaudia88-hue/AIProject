/* ============================================================
   SETTINGS — shared by the landing page, checkout and thank-you page.
   This is the only file you need to edit (plus the Vercel env vars).
   ============================================================ */
window.LP = {
  // Stripe → Developers → API keys → "Publishable key" (starts with pk_live_ or pk_test_)
  stripePublishableKey: "pk_live_REPLACE_ME",

  // Where each name + email is sent the moment someone fills in the form,
  // so you keep every lead even if they don't pay. Any URL that accepts a POST:
  // a Make / Zapier webhook, Formspree, a Google Apps Script. "" = off.
  leadWebhook: "",

  // Meta pixel ID (Events Manager). "" = off.
  metaPixelId: "",

  // Where buyers go to get the product after paying (download / members link).
  accessUrl: "https://aifounderuniversity.com/members/",

  // What the pages display. The real amount charged is set on the server
  // (PRICE_CENTS env var, default 100 = $1.00) so nobody can change it.
  priceLabel: "$1",
  productName: "70 AI Specialists for Claude",
  supportEmail: "support@aifounderuniversity.com"
};

/* ---------- Meta pixel (loads only when an ID is set) ---------- */
(function () {
  var id = window.LP.metaPixelId;
  if (!id) { window.lpTrack = function () {}; return; }
  !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', id);
  fbq('track', 'PageView');
  window.lpTrack = function (ev, data, opts) { try { fbq('track', ev, data || {}, opts || {}); } catch (e) {} };
})();
